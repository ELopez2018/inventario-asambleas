import{k as o}from"./chunk-VGTG44BJ.js";var e=new o(()=>!1);export{e as a};

var n={production:!0,apiBaseUrl:"https://api.inventario.chichinacds.com.co/inventory/api/v1"};var t=n.apiBaseUrl;export{t as a};
